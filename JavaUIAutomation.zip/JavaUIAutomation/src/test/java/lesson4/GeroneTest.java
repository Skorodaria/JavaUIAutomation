package lesson4;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.example.lesson4.GeroneSquare;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GeroneTest {
    private static Logger logger = LoggerFactory.getLogger(GeroneTest.class);
    logger.error("error");

    @BeforeAll
     void beforeAll() {
        WebDriverManager.chromedriver().setup();
        System.out.println("Метод выполнится 1 раз перед всеми тестами данного класса");

    }
     @Test
      void givenGeroneWhenCallIsGeroneThenResult(13,15,18)  {
        boolean result = GeroneSquare.geroneSquare(int result);
        Assertions.assertTrue(true);
    }
   @ParameterizedTest
    @ValueSource(ints = )
   void checkGeroneWhenCallIsGeroneThenResuit(int p);
   boolean result = GeroneSquare.geroneSquare();


   private static Stream<Double> SquareProvaider() {
       Stream<Double> sqrt = Stream.of(Math.sqrt(p * (p - a) * (p - b) * (p - c));
       return sqrt;
   }
}
