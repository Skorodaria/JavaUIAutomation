package org.example.lesson6;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class WildTest {
    WebDriver driver;

    @BeforeAll
    static void registerDriver() {

        WebDriverManager.chromedriver().setup();
    }

    @BeforeEach
    void initDriver() {
        driver = new ChromeDriver();
        driver.get("https://www.wildberries.ru/security/login?returnUrl=https%3A%2F%2Fwww.wildberries.ru%2F");

    }

    @Test
    public void clickRegistration() throws InterruptedException {
        Thread.sleep(5000);
   LoginPage loginPage = new LoginPage(driver);
   loginPage.textField.sendKeys("9312253192");
   loginPage.requestField.click();
   Thread.sleep(5000);

    }


    @AfterEach
    void killdriver() {
        driver.quit();
    }
}
